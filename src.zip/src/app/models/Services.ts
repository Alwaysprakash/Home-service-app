export interface Services{
    id:number,
    name:string,
    desc:string,
    status:string
}