export interface ServiceProviders{

               
    id:number,
     serviceName:string,
    desc:string,
    contact:number,
    email:string,
    address:string,
    location:string,
    city:string,
    zipCode:number,
    website:string
       
}