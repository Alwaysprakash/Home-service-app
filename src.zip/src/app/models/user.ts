export interface User{
    id:number,
    name:string,
    email:string,
    mobile:number,
    password:string,
    usertype:string

}

