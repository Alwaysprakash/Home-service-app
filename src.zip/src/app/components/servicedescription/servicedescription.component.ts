import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicedescription',
  templateUrl: './servicedescription.component.html',
  styleUrls: ['./servicedescription.component.css']
})
export class ServicedescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
